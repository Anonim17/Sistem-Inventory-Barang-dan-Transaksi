<footer class="sticky-footer" style="background-color: rgba(255, 0, 0,0.65 );">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span style="color:#ffffff;">Copyright &copy; {{ $applicationCopyright }}</span>
        </div>
    </div>
</footer>