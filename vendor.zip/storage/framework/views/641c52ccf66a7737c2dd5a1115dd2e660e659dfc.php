<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form class="modal-content" method="POST" action="<?php echo e(url('logout')); ?>">
            <?php echo csrf_field(); ?>
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ingin pergi ?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Tekan tombol "Logout" untuk keluar dari akun.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary" href="login.html" style="background-color: #ff0000;">Logout</button>
            </div>
        </form>
    </div>
</div><?php /**PATH D:\Data\Document\BIMA EC\Program\laravel8-inventory-free\resources\views/components/logout-modal.blade.php ENDPATH**/ ?>