

<?php $__env->startSection('title', "$application->name - Ubah Kata Sandi"); ?>

<?php $__env->startSection('description', 'Halaman formulir untuk mengubah kata sandi pengguna.'); ?>

<?php $__env->startSection('route_name', 'Ubah Kata Sandi'); ?>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="m-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            Berhasil mengubah kata sandi.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header">
            Isi formulir
        </div>
        <div class="card-body">
            <form action="<?php echo e(url('change-password')); ?>" method="POST">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="row align-items-center">
                    <div class="col-md-5 col-lg-3">
                        <label for="old_password">
                            Kata Sandi Lama
                        </label>
                    </div>
                    <div class="col-md-7 col-lg-9 mb-3">
                        <input type="password"
                            class="form-control"
                            name="old_password"
                            id="old_password">
                    </div>
                    <div class="col-md-5 col-lg-3">
                        <label for="newpassword">
                            Kata Sandi Baru
                        </label>
                    </div>
                    <div class="col-md-7 col-lg-9 mb-3">
                        <input type="password"
                            class="form-control"
                            name="newpassword"
                            id="newpassword">
                    </div>
                    <div class="col-md-5 col-lg-3">
                        <label for="newpassword_confirmation">
                            Konfirmasi Kata Sandi
                        </label>
                    </div>
                    <div class="col-md-7 col-lg-9 mb-3">
                        <input type="password"
                            class="form-control"
                            name="newpassword_confirmation"
                            id="newpassword_confirmation"
                            placeholder="Ketik Kembali Kata Sandi Baru...">
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-block btn-primary">
                            Simpan
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\laravel8-inventory-free\resources\views/pages/change-password/edit.blade.php ENDPATH**/ ?>