<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <?php echo e($applicationCopyright); ?></span>
        </div>
    </div>
</footer><?php /**PATH C:\Users\asus\laravel8-inventory-free\resources\views/components/footer.blade.php ENDPATH**/ ?>