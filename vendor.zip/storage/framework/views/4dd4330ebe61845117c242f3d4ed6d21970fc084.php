    

    <?php $__env->startSection('title', "$application->name - Transaksi Keluar - $item->reference_number"); ?>

    <?php $__env->startSection('description', 'Halaman yang berisi informasi detail transaksi Kelar.'); ?>

    <?php $__env->startSection('route_name', 'Detail Transaksi (Keluar)'); ?>

    <?php $__env->startSection('content'); ?>
        <div class="card">
            <div class="card-header">
                <h5 class="m-0 text-dark">
                    <?php echo e($item->reference_number); ?>

                </h5>
            </div>
            <div class="card-body" id="print-content">
                <div class="row mb-2">
                    <div class="col-md-4 col-lg-3">
                        <b>Merk <span class="d-md-none">:</span></b>
                    </div>
                    <div class="col-md-8 col-lg-9">
                        <b class="d-none d-md-inline">:</b> <?php echo e($item->picker); ?>

                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4 col-lg-3">
                        <b>Catatan <span class="d-md-none">:</span></b>
                    </div>
                    <div class="col-md-8 col-lg-9">
                        <b class="d-none d-md-inline">:</b> <?php echo e($item->remarks); ?>

                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        <b>Daftar Barang</b>
                        <div class="table-responsive mt-2">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th class="align-middle">No</th>
                                        <th class="align-middle text-left">ID Barang</th>
                                        <th class="align-middle text-left">Deskripsi</th>
                                        <th class="align-middle">Harga</th>
                                        <th class="align-middle text-right">Satuan Barang</th>
                                        <th class="align-middle text-right">Jumlah</th>
                                        
                                        <th class="align-middle text-right">Harga Total</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $number = 1;
                                        $itemTotal = 0;
                                        $totalPrice = 0;
                                    ?>
                                    <?php $__currentLoopData = $subitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenditureTransactionItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="align-middle">
                                                <?php echo e($number); ?>

                                            </td>
                                            <td class="align-middle text-left">
                                                <?php echo e($expenditureTransactionItem->item->part_number); ?>

                                            </td>
                                            <td class="align-middle text-left">
                                                <?php echo e($expenditureTransactionItem->item->description); ?>

                                            </td>
                                            <td class="align-middle">
                                            <?php echo e('Rp' . currency( $expenditureTransactionItem->item->price)); ?>

                                            </td>
                                            <td class="align-middle text-left">
                                                <?php echo e($expenditureTransactionItem->item->satuan_brg); ?>

                                            </td>
                                            <td class="align-middle text-right">
                                                <?php echo e($expenditureTransactionItem->amount); ?>

                                            </td>
                                            <td class="align-middle text-right">
                                            <?php echo e(currency($expenditureTransactionItem->item->price) * $expenditureTransactionItem->amount); ?>

                                            </td>
                                        </tr>
                                        <?php
                                            $number++;
                                            $itemTotal += $expenditureTransactionItem->amount;
                                            $totalPrice += $expenditureTransactionItem->item->price * $expenditureTransactionItem->amount;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="5" class="text-right">
                                            Total
                                        </th>
                                        <th class="text-right">
                                            <?php echo e($itemTotal); ?>

                                        </th>
                                        <th class="text-right">
                                            <?php echo e(currency($totalPrice)); ?>

                                        </th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
           <div class="card-footer text-right">
            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">
                Kembali
            </a>
         <button class="btn btn-primary" style="background-color: #ff0000;" onclick="printCardBody()">Cetak</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function printCardBody() {
            var printContents = document.getElementById("print-content").innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel8-inventory-free\resources\views/pages/expenditure-transaction/detail.blade.php ENDPATH**/ ?>