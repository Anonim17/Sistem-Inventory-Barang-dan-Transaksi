

<?php $__env->startSection('description', 'Halaman yang berisi formulir untuk membuat data barang.'); ?>

<?php $__env->startSection('route_name', 'Tambah Barang'); ?>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="m-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header bg-white">
            Isi Formulir
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('items.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo method_field('POST'); ?>
                <?php echo csrf_field(); ?>
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="part_number">Kode Barang</label>
                            <input type="text" class="form-control" id="part_number" value="<?php echo e(old('part_number')); ?>" name="part_number">
                        </div>
                    </div>
              
                    <div class="col-12">
                        <div class="form-group">
                            <label for="description">Deskripsi</label>
                            <textarea name="description" id="description" class="form-control"><?php echo e(old('description')); ?></textarea>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="price">Harga</label>
                            <input type="number" class="form-control" id="price" name="price" value="<?php echo e(old('price')); ?>">
                        </div>
                    </div>
                      <div class="col-md-6">
    <div class="form-group">
        <label for="satuan_brg">Satuan Barang</label>
        <select class="form-control" id="satuan_brg" name="satuan_brg">
            <option value="gram">Gram</option>
            <option value="kilogram">Kilogram</option>
            <option value="pcs">Pcs</option>
        </select>
    </div>
</div>
                 
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="image">Gambar</label>
                            <input type="file" class="form-control" id="image" name="image">
                        </div>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">
                            Simpan
                        </button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">
                            Kembali
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel8-inventory-free\resources\views/pages/item/create.blade.php ENDPATH**/ ?>