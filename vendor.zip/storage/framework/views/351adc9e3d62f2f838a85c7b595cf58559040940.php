<!DOCTYPE html>
<html lang="en">

<?php if (isset($component)) { $__componentOriginal0ffb0a0d50d0f581dbd60338c0b56c81fed4e7d6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Head::class, []); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ffb0a0d50d0f581dbd60338c0b56c81fed4e7d6)): ?>
<?php $component = $__componentOriginal0ffb0a0d50d0f581dbd60338c0b56c81fed4e7d6; ?>
<?php unset($__componentOriginal0ffb0a0d50d0f581dbd60338c0b56c81fed4e7d6); ?>
<?php endif; ?>

<body id="page-top">
    <div class="fixed-top min-vw-100 min-vh-100 bg-light justify-content-center align-items-center d-flex" id="pageLoader" style="z-index: 1051">
        <div class="spinner-border" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    
    <div id="wrapper">

        
        <?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Sidebar::class, ['applicationName' => ''.e($application->name).'']); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>
        

        
        <div id="content-wrapper" class="d-flex flex-column">

            
            <div id="content">

                
                <?php if (isset($component)) { $__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Topbar::class, []); ?>
<?php $component->withName('topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6)): ?>
<?php $component = $__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6; ?>
<?php unset($__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6); ?>
<?php endif; ?>
                

                
                <div class="container-fluid">

                    
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800"><?php echo $__env->yieldContent('route_name'); ?></h1>
                    </div>

                    
                    <?php echo $__env->yieldContent('content'); ?>

                </div>
                

            </div>
            

            
            <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, ['applicationCopyright' => ''.e($application->copyright).'']); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
            

        </div>
        

    </div>
    

    
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    
    <?php if (isset($component)) { $__componentOriginal7e42998b145863dd7b639bc67688377ebef10151 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\LogoutModal::class, []); ?>
<?php $component->withName('logout-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7e42998b145863dd7b639bc67688377ebef10151)): ?>
<?php $component = $__componentOriginal7e42998b145863dd7b639bc67688377ebef10151; ?>
<?php unset($__componentOriginal7e42998b145863dd7b639bc67688377ebef10151); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginale897f15469526e6bb29848b9fcf70c3214246b74 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Script::class, []); ?>
<?php $component->withName('script'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale897f15469526e6bb29848b9fcf70c3214246b74)): ?>
<?php $component = $__componentOriginale897f15469526e6bb29848b9fcf70c3214246b74; ?>
<?php unset($__componentOriginale897f15469526e6bb29848b9fcf70c3214246b74); ?>
<?php endif; ?>
    <?php echo $__env->yieldContent('scripts'); ?>

</body>

</html><?php /**PATH C:\Users\asus\laravel8-inventory-free\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>