

<?php $__env->startSection('title', "$application->name - Pengguna - Tambah"); ?>

<?php $__env->startSection('description', 'Halaman yang berisi formulir untuk membuat data pengguna.'); ?>

<?php $__env->startSection('route_name', 'Tambah Pengguna'); ?>

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul class="m-0">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<div class="card">
    <div class="card-header bg-white">
        Isi Formulir
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('users.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="name">Nama</label>
                        <input type="text" class="form-control" id="name" value="<?php echo e(old('name')); ?>" name="name">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" id="username" value="<?php echo e(old('username')); ?>" name="username">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" value="<?php echo e(old('email')); ?>" name="email">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="password">Kata Sandi</label>
                        <input type="password" class="form-control" id="password" name="password">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="role">Jenis</label>
                        <select name="role" id="role" class="form-control">
                            <option value="">-- Pilih --</option>
                            <option value="Admin" <?php echo e(old('role') === 'Admin' ? 'selected' : ''); ?>>
                                Admin
                            </option>
                            <option value="Pemilik" <?php echo e(old('role') === 'Pemilik' ? 'selected' : ''); ?>>
                                Pemilik
                            </option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="id_cabang">Kantor Cabang</label>
                        <select name="id_cabang" id="id_cabang" class="form-control">
                            <option value="">-- Pilih --</option>
                            <?php $__currentLoopData = $cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_cabang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data_cabang->id_cabang); ?>">
                                <?php echo e($data_cabang->keterangan_cabang); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary" style="background-color: #ff0000;">
                        Simpan
                    </button>
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">
                        Kembali
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Document\BIMA EC\Program\laravel8-inventory-free\resources\views/pages/user/create.blade.php ENDPATH**/ ?>