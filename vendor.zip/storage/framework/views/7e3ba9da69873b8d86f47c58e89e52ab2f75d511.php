<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\xampp\htdocs\laravel8-inventory-free\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>