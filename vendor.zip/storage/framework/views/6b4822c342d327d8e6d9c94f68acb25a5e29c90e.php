

<?php $__env->startSection('title', "$application->name - Kategori"); ?>

<?php $__env->startSection('description', 'Halaman yang berisi daftar kategori yang dibuat.'); ?>

<?php $__env->startSection('route_name', 'Kategori'); ?>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="m-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('status')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <div class="row justify-content-end">
        <div class="col-auto">
            <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-sm btn-primary mb-3">
                <i class="fas fa-plus mr-1"></i>
                Tambah
            </a>
        </div>
    </div>
    <div class="card">
        <div class="card-header bg-white">
            <div class="row justify-content-center justify-content-lg-between align-items-center">
                <div class="col-md-7 col-lg-4 col-xl-3 mb-2 mb-md-0">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-md-auto">
                            <label for="sort" class="m-0 font-weight-bold">Urutan</label>
                        </div>
                        <div class="col p-md-0">
                            <select class="form-control form-control-sm" onchange="window.location.replace(this.value)">
                                <option value="<?php echo e(route('categories.index', ['order_by' => 'name', 'order_direction' => 'asc'])); ?>"
                                    <?php echo e($input['order_by'] === 'name' && $input['order_direction'] === 'asc' ? 'selected' : ''); ?>>
                                    Nama (Menaik)
                                </option>
                                <option value="<?php echo e(route('categories.index', ['order_by' => 'name', 'order_direction' => 'asc'])); ?>"
                                    <?php echo e($input['order_by'] === 'name' && $input['order_direction'] === 'asc' ? 'selected' : ''); ?>>
                                    Nama (Menurun)
                                </option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-lg-auto col-md-5 col-lg-3">
                    <form action="<?php echo e(route('categories.index')); ?>" method="get">
                        <input type="hidden" name="order_by" value="<?php echo e($input['order_by']); ?>">
                        <input type="hidden" name="order_direction" value="<?php echo e($input['order_direction']); ?>">
                        <div class="input-group input-group-sm">
                            <input type="search"
                                class="form-control"
                                name="keyword"
                                id="q"
                                placeholder="Pencarian"
                                value="<?php echo e(empty($input['keyword']) ? '' : $input['keyword']); ?>">
                            <div class="input-group-append">
                              <button class="btn btn-outline-secondary" type="submit" id="button-addon2">
                                <i class="fas fa-search"></i>
                              </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive mb-3">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 2px">No</th>
                            <th class="text-center">ID</th>
                            <th>Nama</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($items->isEmpty()): ?>
                            <tr>
                                <td class="text-center" colspan="4">
                                    Data tidak ditemukan.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center align-middle">
                                        <?php echo e($number); ?>

                                    </td>
                                    <td class="text-center align-middle">
                                        <?php echo e($item->id); ?>

                                    </td>
                                    <td class="align-middle">
                                        <?php echo e($item->name); ?>

                                    </td>
                                    <td class="text-center align-middle">
                                        <a href="<?php echo e(route('categories.edit', $item->id)); ?>" class="btn btn-warning btn-sm my-1 my-lg-0">
                                            Ubah
                                        </a>
                                        <form action="<?php echo e(route('categories.destroy', $item->id)); ?>" method="post" class="d-inline my-1 my-lg-0">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Data lain yang menggunakan kategori ini akan ikut terhapus. Lanjutkan ?')">
                                                Hapus
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php
                                    $number++
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="row justify-content-end">
                <div class="col-auto">
                    <nav>
                        <ul class="pagination pagination-sm">
                            <?php if($input['page'] === 1): ?>
                                <li class="page-item disabled">
                                    <a href="" class="page-link"><<</a>
                                </li>

                                <li class="page-item disabled">
                                    <a href="" class="page-link"><</a>
                                </li>

                                <li class="page-item active">
                                    <a
                                        href="<?php echo e(route('categories.index', ['page' => 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>"
                                        class="page-link">
                                        1
                                    </a>
                                </li>

                                <?php for($i = 2; $i <= $pageTotal; $i++): ?>
                                    <?php if($i < 4): ?>
                                        <li class="page-item">
                                            <a class="page-link"
                                                href="<?php echo e(route('categories.index', ['page' => $i, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                                <?php echo e($i); ?>

                                            </a>
                                        </li>
                                    <?php endif; ?>
                                <?php endfor; ?>

                                <li class="page-item">
                                    <a class="page-link"
                                        href="<?php echo e(route('categories.index', ['page' => $input['page'] + 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                        >
                                    </a>
                                </li>

                                <li class="page-item">
                                    <a class="page-link"
                                        href="<?php echo e(route('categories.index', ['page' => $pageTotal, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                        >>
                                    </a>
                                </li>
                            <?php else: ?>
                                <li class="page-item">
                                    <a class="page-link"
                                        href="<?php echo e(route('categories.index', ['page' => 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                        <<
                                    </a>
                                </li>

                                <li class="page-item">
                                    <a class="page-link"
                                        href="<?php echo e(route('categories.index', ['page' => $input['page'] - 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                        <
                                    </a>
                                </li>

                                <?php
                                    $pageStartNumber = $input['page'] !== $pageTotal ? $input['page'] - 1 : $input['page'] - 2;
                                    $loopingNumberStop = $input['page'] !== $pageTotal ? $input['page'] + 1 : $input['page'];
                                    $pageStartNumber = $pageStartNumber < 1 ? 1 : $pageStartNumber;
                                ?>

                                <?php for($i = $pageStartNumber; $i <= $loopingNumberStop; $i++): ?>
                                    <li class="page-item <?php echo e($input['page'] === $i ? 'active' : ''); ?>">
                                        <a class="page-link"
                                            href="<?php echo e(route('categories.index', ['page' => $i, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                            <?php echo e($i); ?>

                                        </a>
                                    </li>
                                <?php endfor; ?>

                                <li class="page-item <?php echo e($input['page'] === $pageTotal ? 'disabled' : ''); ?>">
                                    <a class="page-link"
                                        href="<?php echo e(route('categories.index', ['page' => $input['page'] + 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                        >
                                    </a>
                                </li>

                                <li class="page-item <?php echo e($input['page'] === $pageTotal ? 'disabled' : ''); ?>">
                                    <a class="page-link"
                                        href="<?php echo e(route('categories.index', ['page' => $pageTotal, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                        >>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\laravel8-inventory-free\resources\views/pages/category/index.blade.php ENDPATH**/ ?>