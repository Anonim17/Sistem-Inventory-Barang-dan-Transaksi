

<?php $__env->startSection('title', "$application->name - Barang - Ubah"); ?>

<?php $__env->startSection('description', 'Halaman yang berisi formulir untuk mengubah data barang.'); ?>

<?php $__env->startSection('route_name', 'Ubah Barang'); ?>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="m-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header bg-white">
            Isi Formulir
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('items.update', $item->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="part_number">Kode Barang</label>
                            <input type="text"
                                class="form-control"
                                id="part_number"
                                value="<?php echo e(empty(old('part_number')) ? $item->part_number : old('part_number')); ?>"
                                name="part_number">
                        </div>
                    </div>
            
                    <div class="col-12">
                        <div class="form-group">
                            <label for="description">Deskripsi</label>
                            <textarea name="description" id="description" class="form-control"><?php echo e(empty(old('description')) ? $item->description : old('description')); ?></textarea>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="price">Harga</label>
                            <input type="number" max="9999999999" class="form-control" id="price" name="price" value="<?php echo e(empty(old('price')) ? intval($item->price) : old('price')); ?>">
                        </div>
                    </div>
                       <div class="col-md-6">
                       <div class="form-group">
        <label for="satuan_brg">Satuan Barang</label>
        <select class="form-control" id="satuan_brg" name="satuan_brg">
            <option value="gram">Gram</option>
            <option value="kilogram">Kilogram</option>
            <option value="pcs">Pcs</option>
        </select>
    </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="image">Gambar</label>
                            <input type="file" class="form-control" id="image" name="image">
                        </div>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">
                            Simpan
                        </button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">
                            Kembali
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Document\BIMA EC\Program\laravel8-inventory-free\resources\views/pages/item/edit.blade.php ENDPATH**/ ?>