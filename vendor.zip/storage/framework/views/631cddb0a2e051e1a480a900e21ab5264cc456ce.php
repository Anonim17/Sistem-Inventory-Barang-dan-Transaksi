

<?php $__env->startSection('title', "$application->name - Transaksi (Keluar)"); ?>

<?php $__env->startSection('description', 'Halaman yang berisi daftar data transaksi keluar yang dibuat.'); ?>

<?php $__env->startSection('route_name', 'Transaksi (Keluar)'); ?>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="m-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('status')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
     
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
    <div class="row justify-content-end">
        <div class="col-auto">
            <a href="<?php echo e(route('expenditure-transactions.create')); ?>" class="btn btn-sm btn-primary mb-3" style="background-color: #ff0000";>
                <i class="fas fa-plus mr-1"></i>
                Tambah
            </a>
        </div>
    </div>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isPemilik')): ?>
    <div class="row justify-content-end">
        <div class="col-auto">
            <a href="javascript:void(0)" class="btn btn-sm btn-primary mb-3" style="background-color: #ff0000;" onclick="printContent()">
                
                Cetak
            </a>
        </div>
    </div>
    <?php endif; ?>
    <!-- Modal -->
    <div class="modal fade" id="filterModal" tabindex="-1" aria-labelledby="filterModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form class="modal-content" action="<?php echo e(route('expenditure-transactions.index')); ?>" method="GET">
                <div class="modal-header">
                    <h5 class="modal-title" id="filterModalLabel">Sortir / Saring Transaksi (Keluar)</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="background-color: #ff0000;">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <input type="hidden" name="keyword" value="<?php echo e($input['keyword']); ?>">
                        <label for="order_by">Kolom Urut</label>
                        <select class="form-control form-control-sm" id="order_by" name="order_by">
                            <option value="created_at"
                                <?php echo e($input['order_by'] === 'created_at' ? 'selected' : ''); ?>>
                                Tanggal
                            </option>
                            <option value="picker"
                                <?php echo e($input['order_by'] === 'picker' ? 'selected' : ''); ?>>
                                Merk
                            </option>
                            <option value="reference_number"
                                <?php echo e($input['order_by'] === 'reference_number' ? 'selected' : ''); ?>>
                                Nomor Nota
                            </option>
                            <option value="remarks"
                                <?php echo e($input['order_by'] === 'remarks' ? 'selected' : ''); ?>>
                                Catatan
                            </option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="order_direction">Arah Urut</label>
                        <select name="order_direction" id="order_direction" class="form-control form-control-sm">
                            <option value="desc"
                                <?php echo e($input['order_direction'] === 'desc' ? 'selected' : ''); ?>>
                                Turun
                            </option>
                            <option value="asc"
                                <?php echo e($input['order_direction'] === 'asc' ? 'selected' : ''); ?>>
                                Naik
                            </option>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="string_start_date">Tanggal Mulai</label>
                                <input type="date"
                                    class="form-control"
                                    value="<?php echo e($input['string_start_date']); ?>"
                                    id="string_start_date"
                                    name="string_start_date"
                                    onkeyup="document.getElementById('start_date').value = new Date(this.value).getTime() / 1000"
                                    onchange="document.getElementById('start_date').value = new Date(this.value).getTime() / 1000">
                                <input type="hidden"
                                    name="start_date"
                                    id="start_date"
                                    value="<?php echo e($input['start_date']); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="string_end_date">Tanggal Akhir</label>
                                <input type="date"
                                    class="form-control"
                                    value="<?php echo e($input['string_end_date']); ?>"
                                    id="string_end_date"
                                    name="string_end_date"
                                    onkeyup="document.getElementById('end_date').value = new Date(this.value).getTime() / 1000"
                                    onchange="document.getElementById('end_date').value = new Date(this.value).getTime() / 1000">
                                <input type="hidden"
                                    name="end_date"
                                    id="end_date"
                                    value="<?php echo e($input['end_date']); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
    <div class="card">
        <div class="card-header bg-white">
            <div class="row justify-content-center justify-content-lg-between align-items-center">
                <div class="col-md-7 col-lg-4 mb-2 mb-lg-0">
                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#filterModal"style="background-color: #ff0000;">
                        <i class="fas fa-filter mr-1" style="background-color: #ff0000;"></i>
                        Sortir / Saring
                    </button>
                </div>
                <div class="col-lg-auto col-md-6">
                    <form action="<?php echo e(route('expenditure-transactions.index')); ?>" method="get">
                        <input type="hidden" name="order_by" value="<?php echo e($input['order_by']); ?>">
                        <input type="hidden" name="order_direction" value="<?php echo e($input['order_direction']); ?>">
                        <input type="hidden" name="start_date" value="<?php echo e($input['start_date']); ?>">
                        <input type="hidden" name="end_date" value="<?php echo e($input['end_date']); ?>">
                        <div class="input-group input-group-sm">
                            <input type="search"
                                class="form-control"
                                name="keyword"
                                id="q"
                                placeholder="Pencarian"
                                value="<?php echo e(empty($input['keyword']) ? '' : $input['keyword']); ?>">
                            <div class="input-group-append">
                              <button class="btn btn-outline-secondary" type="submit" id="button-addon2">
                                <i class="fas fa-search"></i>
                              </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive mb-3">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center align-middle" style="width: 2px">No</th>
                            <th class="align-middle text-center">Tanggal (WIB)</th>
                            <th class="align-middle text-center">Nomor Nota</th>
                            <th class="align-middle">Merk</th>
                            <th class="align-middle">Catatan</th>
                            <th class="align-middle">Cabang</th>
                            
                            <th class="align-middle">Keterangan</th>
                            
                            <th class="align-middle"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($items->isEmpty()): ?>
                            <tr>
                                <td class="text-center" colspan="6">
                                    Data tidak ditemukan.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center align-middle">
                                        <?php echo e($number); ?>

                                    </td>
                                    <td class="align-middle text-center unix-column">
                                        <?php echo e($item->created_at); ?>

                                    </td>
                                    <td class="align-middle text-center">
                                        <?php echo e($item->reference_number); ?>

                                    </td>
                                    <td class="align-middle">
                                        <?php echo e($item->picker); ?>

                                    </td>
                                    <td class="align-middle">
                                        <?php if($item->remarks == '1'): ?>
                                            "Diterima"
                                        <?php elseif($item->remarks == '2'): ?>
                                            "Belum Disetujui"
                                        <?php else: ?>
                                            "Ditolak"
                                        <?php endif; ?>
                                    </td>
                                    <td class="align-middle">
                                        <?php echo e($item->keterangan_cabang); ?>

                                    </td>
                                    <td class="align-middle">
                                        <?php echo e($item->keterangan); ?>

                                    </td>
                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                                    <td class="text-center align-middle">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-secondary dropdown-toggle btn-sm" data-toggle="dropdown" aria-expanded="false">
                                              Aksi
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a href="<?php echo e(route('expenditure-transactions.show', $item->id)); ?>" class="dropdown-item">
                                                    Detail
                                                </a>
                                                <a href="<?php echo e(route('expenditure-transactions.edit', $item->id)); ?>" class="dropdown-item">
                                                    Ubah
                                                </a>
                                                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                                                <form action="<?php echo e(route('expenditure-transactions.destroy', $item->id)); ?>" method="post" class="dropdown-item">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="dropdown-item text-left p-0" onclick="return confirm('Transaksi <?php echo e($item->reference_number); ?> akan dihapus. Lanjutkan')">
                                                        Hapus
                                                    </button>
                                                </form>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>         
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isPemilik')): ?>
<td class="text-center align-middle">
    <form id="remarksForm" action="<?php echo e(route('expenditure-transactions.update', $item->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label for="keterangan">Keterangan</label>
            <textarea name="keterangan" id="keterangan" class="form-control"><?php echo e(empty(old('keterangan')) ? $item->keterangan : old('keterangan')); ?></textarea>
        </div>

        <div class="form-group">
            <label>Pilih Status</label>
            <div class="btn-group btn-group-toggle" data-toggle="buttons">
                <label class="btn btn-outline-success <?php echo e($item->remarks === '1' ? 'active' : ''); ?>">
                    <input type="radio" name="remarks" value="1" autocomplete="off" <?php echo e($item->remarks === '1' ? 'checked' : ''); ?>> Diterima
                </label>
                <label class="btn btn-outline-danger <?php echo e($item->remarks === '0' ? 'active' : ''); ?>">
                    <input type="radio" name="remarks" value="0" autocomplete="off" <?php echo e($item->remarks === '0' ? 'checked' : ''); ?>> Ditolak
                </label>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>

        <a href="<?php echo e(route('expenditure-transactions.show', $item->id)); ?>" class="btn btn-secondary">
            Detail
        </a>
    </form>
</td>

<script>
    const submitButton = document.querySelector('button[type="submit"]');
    const radioButtons = document.querySelectorAll('input[type="radio"]');

    radioButtons.forEach((radio) => {
        radio.addEventListener('click', () => {
            submitButton.removeAttribute('disabled');
        });
    });
</script>
<?php endif; ?>


                                </tr>
                                <?php
                                    $number++
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="row justify-content-end">
                <div class="col-auto">
                    <nav>
                        <ul class="pagination pagination-sm">
                            <?php if($input['page'] === 1): ?>
                                <li class="page-item disabled">
                                    <a href="" class="page-link"><<</a>
                                </li>

                                <li class="page-item disabled">
                                    <a href="" class="page-link"><</a>
                                </li>

                                <li class="page-item active">
                                    <a
                                        href="<?php echo e(route('expenditure-transactions.index', ['page' => 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>"
                                        class="page-link">
                                        1
                                    </a>
                                </li>

                                <?php for($i = 2; $i <= $pageTotal; $i++): ?>
                                    <?php if($i < 4): ?>
                                        <li class="page-item">
                                            <a class="page-link"
                                                href="<?php echo e(route('expenditure-transactions.index', ['page' => $i, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                                <?php echo e($i); ?>

                                            </a>
                                        </li>
                                    <?php endif; ?>
                                <?php endfor; ?>

                                <li class="page-item">
                                    <a class="page-link"
                                        href="<?php echo e(route('expenditure-transactions.index', ['page' => $input['page'] + 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                        >
                                    </a>
                                </li>

                                <li class="page-item">
                                    <a class="page-link"
                                        href="<?php echo e(route('expenditure-transactions.index', ['page' => $pageTotal, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                        >>
                                    </a>
                                </li>
                            <?php else: ?>
                                <li class="page-item">
                                    <a class="page-link"
                                        href="<?php echo e(route('expenditure-transactions.index', ['page' => 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                        <<
                                    </a>
                                </li>

                                <li class="page-item">
                                    <a class="page-link"
                                        href="<?php echo e(route('expenditure-transactions.index', ['page' => $input['page'] - 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                        <
                                    </a>
                                </li>

                                <?php
                                    $pageStartNumber = $input['page'] !== $pageTotal ? $input['page'] - 1 : $input['page'] - 2;
                                    $loopingNumberStop = $input['page'] !== $pageTotal ? $input['page'] + 1 : $input['page'];
                                    $pageStartNumber = $pageStartNumber < 1 ? 1 : $pageStartNumber;
                                ?>

                                <?php for($i = $pageStartNumber; $i <= $loopingNumberStop; $i++): ?>
                                    <li class="page-item <?php echo e($input['page'] === $i ? 'active' : ''); ?>">
                                        <a class="page-link"
                                            href="<?php echo e(route('expenditure-transactions.index', ['page' => $i, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                            <?php echo e($i); ?>

                                        </a>
                                    </li>
                                <?php endfor; ?>

                                <li class="page-item <?php echo e($input['page'] === $pageTotal ? 'disabled' : ''); ?>">
                                    <a class="page-link"
                                        href="<?php echo e(route('expenditure-transactions.index', ['page' => $input['page'] + 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                        >
                                    </a>
                                </li>

                                <li class="page-item <?php echo e($input['page'] === $pageTotal ? 'disabled' : ''); ?>">
                                    <a class="page-link"
                                        href="<?php echo e(route('expenditure-transactions.index', ['page' => $pageTotal, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword']])); ?>">
                                        >>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body"style="display: none;" id="printall">
            <div class="table-responsive mb-3">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center align-middle" style="width: 2px">No</th>
                            <th class="align-middle text-center">Tanggal (WIB)</th>
                            <th class="align-middle text-center">Nomor Nota</th>
                            <th class="align-middle">Merk</th>
                            <th class="align-middle">Catatan</th>
                            <th class="align-middle">Cabang</th>
                            <th class="align-middle">Keterangan</th>
                            <th class="align-middle"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($items->isEmpty()): ?>
                            <tr>
                                <td class="text-center" colspan="6">
                                    Data tidak ditemukan.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center align-middle">
                                        <?php echo e($number); ?>

                                    </td>
                                    <td class="align-middle text-center unix-column">
                                        <?php echo e($item->created_at); ?>

                                    </td>
                                    <td class="align-middle text-center">
                                        <?php echo e($item->reference_number); ?>

                                    </td>
                                    <td class="align-middle">
                                        <?php echo e($item->picker); ?>

                                    </td>
                                    <td class="align-middle">
                                        <?php if($item->remarks == '1'): ?>
                                            "Diterima"
                                        <?php elseif($item->remarks == '2'): ?>
                                            "Belum Disetujui"
                                        <?php else: ?>
                                            "Ditolak"
                                        <?php endif; ?>
                                    </td>
                                    <td class="align-middle">
                                        <?php echo e($item->keterangan_cabang); ?>

                                    </td>
                                    <td class="align-middle">
                                        <?php echo e($item->keterangan); ?>

                                    </td>                                                                        
                                     </tr>
                                <?php
                                    $number++
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
    </div>
    <script>
          function printContent() {
            var content = document.getElementById("printall").innerHTML;
            var originalContent = document.body.innerHTML;
            document.body.innerHTML = content;
            window.print();
            document.body.innerHTML = originalContent;
        }
        document.getElementById('remarks').addEventListener('change', function() {
            document.getElementById('remarksForm').submit();
        });

        function datetimeLocal(unix) {
            var dt = new Date(unix * 1000);
            dt.setMinutes(dt.getMinutes() - dt.getTimezoneOffset());
            return dt.toISOString().slice(0, 16);
        }

        var htmlCreatedAt = document.getElementById('html_created_at'),
            unix = parseInt(htmlCreatedAt.getAttribute('data-value')),
            date = datetimeLocal(unix);

        htmlCreatedAt.value = date;
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Document\BIMA EC\Program\laravel8-inventory-free\resources\views/pages/expenditure-transaction/index.blade.php ENDPATH**/ ?>