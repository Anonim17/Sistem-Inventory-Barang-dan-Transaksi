

<?php $__env->startSection('title', "$application->name - Kategori - Tambah"); ?>

<?php $__env->startSection('description', 'Halaman yang berisi formulir untuk membuat kategori.'); ?>

<?php $__env->startSection('route_name', 'Tambah Kategori'); ?>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="m-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header bg-white">
            Isi Formulir
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('categories.store')); ?>" method="POST">
                <?php echo method_field('POST'); ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                <div class="row align-items-center">
                    <div class="col-md-2 col-lg-1">
                        <label for="name">
                            Nama
                        </label>
                    </div>
                    <div class="col-md-10 col-lg-11 mb-3">
                        <input type="text"
                            class="form-control"
                            name="name"
                            id="name"
                            value="<?php echo e(old('name')); ?>">
                    </div>
                    <div class="col-12 text-right">
                        <button type="submit" class="btn btn-primary">
                            Simpan
                        </button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">
                            Kembali
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\laravel8-inventory-free\resources\views/pages/category/create.blade.php ENDPATH**/ ?>