

<?php $__env->startSection('title', "$application->name - Dashboard"); ?>

<?php $__env->startSection('description', 'Halaman ringkasan informasi dari aplikasi.'); ?>

<?php $__env->startSection('route_name', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="body">
    <div class="text-center" style="color:#ff0000;">
        <h2 class="h2">Selamat Datang <?php echo e(auth()->user()->name); ?> di Sistem Informasi Inventory</h2>
        <h6 class="h4">Auto Sunrise Mandiri</h6>
    </div>
    <div><img src="<?= url('/template/bg2.jpg') ?>" class="card border-left-primary shadow h-100 py-2 card-img-top"></div>
    <hr>

    <div class="row">
        
        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Jumlah Barang
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($itemTotal); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Jumlah Transaksi (Masuk)
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($incomeTransactionTotal); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-warehouse fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Jumlah Transaksi (Keluar)
                            </div>
                            <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo e($expenditureTransactionTotal); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Document\BIMA EC\Program\laravel8-inventory-free\resources\views/pages/dashboard/index.blade.php ENDPATH**/ ?>