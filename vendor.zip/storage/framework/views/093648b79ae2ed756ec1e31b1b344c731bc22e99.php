

<?php $__env->startSection('title', "$application->name - Transaksi (Masuk) - Tambah"); ?>

<?php $__env->startSection('description', 'Halaman yang berisi formulir untuk membuat data transaksi pemasukkan.'); ?>

<?php $__env->startSection('route_name', 'Tambah Transaksi (Masuk)'); ?>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="m-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('status')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <ul class="nav nav-tabs bg-white" id="myTab" role="tablist">
        <li class="nav-item" role="presentation">
          <button class="nav-link active" id="home-tab" data-toggle="tab" data-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Barang</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="selected-tab" data-toggle="tab" data-target="#selected" type="button" role="tab" aria-controls="selected" aria-selected="false">Terpilih</button>
        </li>
        <li class="nav-item" role="presentation">
          <button class="nav-link" id="profile-tab" data-toggle="tab" data-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Transaksi</button>
        </li>
    </ul>
    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show active bg-white border p-2 px-3" id="home" role="tabpanel">
            <form action="<?php echo e(route('income-transaction-items.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-10">
                        <div class="form-group">
                            <select name="item_id" id="item_id" class="form-control">
                                <option value="">-- Pilih Barang --</option>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e(old('item_id') === $item->id ? 'selected' : ''); ?>>
                                        <?php echo e($item->description); ?>

                                        (<?php echo e($item->part_number); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <input type="number" step="0.001" class="form-control" id="amount" name="amount" placeholder="Jumlah" value="<?php echo e(old('amount')); ?>" >
                        </div>
                    </div>
                    <div class="col-12 text-right">
                        <a href="<?php echo e(route('income-transactions.index')); ?>" class="btn btn-secondary">
                            Kembali
                        </a>
                        <button class="btn btn-primary" type="submit">
                            Tambah
                        </button>
                    </div>
                </div>
            </form>
        </div>
        <div class="tab-pane fade p-2 px-3 bg-white border" id="selected" role="tabpanel">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Nomor Unik</th>
                            <th>Deskripsi</th>
                      
                            <th class="text-center">Jumlah</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($income_transaction_items)): ?>
                            <tr>
                                <td colspan="5" class="text-center">Barang belum dipilih.</td>
                            </tr>
                        <?php else: ?>
                            <?php $__currentLoopData = $income_transaction_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle">
                                        <?php echo e($item->part_number); ?>

                                    </td>
                                    <td class="align-middle">
                                        <?php echo e($item->description); ?>

                                    </td>
                                   
                                    <td class="align-middle text-center">
                                        <?php echo e($item->amount); ?>

                                    </td>
                                    <td class="align-middle text-center">
                                        <form action="<?php echo e(url("income-transaction-items/$item->id/create")); ?>" method="post" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                Hapus
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="text-right">
                <a href="<?php echo e(route('income-transactions.index')); ?>" class="btn btn-secondary">
                    Kembali
                </a>
            </div>
        </div>
        <div class="tab-pane fade p-2 px-3 bg-white border" id="profile" role="tabpanel">
            <form class="row" action="<?php echo e(route('income-transactions.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <div class="col-md-6 col-lg-4">
                    <div class="form-group">
                        <label for="html_created_at">Tanggal</label>
                        <input type="datetime-local"
                            class="form-control"
                            id="html_created_at"
                            name="html_created_at"
                            onkeyup="document.getElementById('created_at').value = +new Date(this.value) / 1000"
                            onchange="document.getElementById('created_at').value = +new Date(this.value) / 1000"
                            data-value="<?php echo e(empty(old('created_at')) ? time() : old('created_at')); ?>">
                        <input type="hidden"
                            name="created_at"
                            id="created_at"
                            value="<?php echo e(empty(old('created_at')) ? time() : old('created_at')); ?>">
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="form-group">
                        <label for="reference_number">Nomor Referensi</label>
                        <input type="text"
                            name="reference_number"
                            id="reference_number"
                            value="<?php echo e(old('reference_number')); ?>"
                            class="form-control">
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="form-group">
                        <label for="supplier">Pemasok</label>
                        <input type="text"
                            class="form-control"
                            id="supplier"
                            name="supplier"
                            value="<?php echo e(old('supplier')); ?>">
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <label for="remarks">Catatan</label>
                        <textarea name="remarks" id="remarks" class="form-control" readonly><?php echo e(old('remarks','Belum Disetujui')); ?></textarea>
                    </div>
                </div>
                <div class="col-12 text-right">
                    <a href="<?php echo e(route('income-transactions.index')); ?>" class="btn btn-secondary">
                        Kembali
                    </a>
                    <button type="submit"
                        class="btn btn-primary">
                        Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
    <script>
        function datetimeLocal(unix) {
            var dt = new Date(unix * 1000);
            dt.setMinutes(dt.getMinutes() - dt.getTimezoneOffset());
            return dt.toISOString().slice(0, 16);
        }

        var htmlCreatedAt = document.getElementById('html_created_at'),
            unix = parseInt(htmlCreatedAt.getAttribute('data-value')),
            date = datetimeLocal(unix);

        htmlCreatedAt.value = date;
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\laravel8-inventory-free\resources\views/pages/income-transaction/create.blade.php ENDPATH**/ ?>