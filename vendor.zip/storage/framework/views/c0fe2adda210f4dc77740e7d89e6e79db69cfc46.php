<ul class="navbar-nav bg-gradient-danger sidebar sidebar-dark accordion" id="accordionSidebar">

    
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(url('dashboard')); ?>">
        <div class="sidebar-brand-text mx-12" style="padding-top:20px;"><?php echo e($applicationName); ?>

        <br><p style="font-size:10px;">Auto Sunrise Mandiri</p>
        </div>
        
    </a>

    
    <hr class="sidebar-divider my-0">

    
    <li class="nav-item <?php echo e((request()->is('dashboard') || request()->is('dashboard/*')) ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('dashboard')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <li class="nav-item <?php echo e(request()->is('items') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('items')); ?>">
            <i class="fas fa-fw fa-desktop"></i>
            <span>Master Data Barang</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link <?php echo e((request()->is('income-transactions') || request()->is('income-transactions/*') || request()->is('expenditure-transactions') || request()->is('expenditure-transactions/*')) ? '' : 'collapsed'); ?>" href="#" data-toggle="collapse" data-target="#collapseThree"
            aria-expanded="<?php echo e((request()->is('income-transactions') || request()->is('income-transactions/*') || request()->is('expenditure-transactions') || request()->is('expenditure-transactions/*')) ? 'true' : 'false'); ?>" aria-controls="collapseThree">
            <i class="fas fa-fw fa-handshake"></i>
            <span>Transaksi</span>
        </a>
        <div id="collapseThree" class="collapse <?php echo e((request()->is('income-transactions') || request()->is('income-transactions/*') || request()->is('expenditure-transactions') || request()->is('expenditure-transactions/*')) ? 'show' : ''); ?>" aria-labelledby="headingThree" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header" >Transaksi:</h6>
                <a class="collapse-item <?php echo e((request()->is('income-transactions') || request()->is('income-transactions/*')) ? 'active' : ''); ?>" href="<?php echo e(url('income-transactions')); ?>">
                    Masuk
                </a>
                <a class="collapse-item <?php echo e((request()->is('expenditure-transactions') || request()->is('expenditure-transactions/*')) ? 'active' : ''); ?>" href="<?php echo e(url('expenditure-transactions')); ?>" >
                    Keluar
                </a>
            </div>
        </div>
    </li>

    <li class="nav-item <?php echo e((request()->is('stocks') || request()->is('stocks/*')) ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('stocks')); ?>">
            <i class="fas fa-fw fa-cubes"></i>
            <span>Stok Barang</span></a>
    </li>

    <li class="nav-item <?php echo e((request()->is('users') || request()->is('users/*')) ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('users')); ?>">
            <i class="fas fa-fw fa-users"></i>
            <span>Pengguna</span></a>
    </li>



    
    <hr class="sidebar-divider d-none d-md-block">

    
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul><?php /**PATH C:\xampp\htdocs\laravel8-inventory-free\resources\views/components/operator-sidebar.blade.php ENDPATH**/ ?>