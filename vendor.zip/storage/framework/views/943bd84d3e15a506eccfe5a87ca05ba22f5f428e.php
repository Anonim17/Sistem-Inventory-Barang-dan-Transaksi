

<?php $__env->startSection('title', "$application->name - Transaksi Masuk - $item->reference_number"); ?>

<?php $__env->startSection('description', 'Halaman yang berisi informasi detail transaksi masuk.'); ?>

<?php $__env->startSection('route_name', 'Detail Transaksi Masuk'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h5 class="m-0 text-dark">
                <?php echo e($item->reference_number); ?>

            </h5>
        </div>
        <div class="card-body" id="print-content">
            <div class="row mb-2">
                <div class="col-md-4 col-lg-3">
                    <b>Pemasok <span class="d-md-none">:</span></b>
                </div>
                <div class="col-md-8 col-lg-9">
                    <b class="d-none d-md-inline">:</b> <?php echo e($item->supplier); ?>

                </div>
            </div>
            <div class="row mb-2">
                <div class="col-md-4 col-lg-3">
                    <b>Catatan <span class="d-md-none">:</span></b>
                </div>
                <div class="col-md-8 col-lg-9">
                    <b class="d-none d-md-inline">:</b> <?php echo e($item->remarks); ?>

                </div>
            </div>
            <div class="row">
                <div class="col-12 text-center">
                    <b>Daftar Barang</b>
                    <div class="table-responsive mt-2">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th class="align-middle">No</th>
                                    <th class="align-middle text-left">Nomor Unik</th>
                                    <th class="align-middle text-left">Deskripsi</th>
                                    <th class="align-middle">harga</th>
                                    <th class="align-middle text-right">Satuan Barang</th>
                                    <th class="align-middle text-right">Jumlah</th>
                                    <th class="align-middle text-right">Harga Total</th>
                                  
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $number = 1;
                                    $itemTotal = 0;
                                    $totalPrice= 0;
                                ?>
                                <?php $__currentLoopData = $subitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incomeTransactionItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="align-middle">
                                            <?php echo e($number); ?>

                                        </td>
                                        <td class="align-middle text-left">
                                            <?php echo e($incomeTransactionItem->item->part_number); ?>

                                        </td>
                                        <td class="align-middle text-left">
                                            <?php echo e($incomeTransactionItem->item->description); ?>

                                        </td>
                                        <td class="align-middle">
                                            <?php echo e('Rp' . currency( $incomeTransactionItem->item->price )); ?>

                                        </td>
                                         <td class="align-middle text-right">
                                            <?php echo e($incomeTransactionItem->item->satuan_brg); ?>

                                        </td>
                                        <td class="align-middle text-right">
                                            <?php echo e($incomeTransactionItem->amount); ?>

                                        </td>
                                        <td class="align-middle text-right">
                                            <?php echo e(currency($incomeTransactionItem->item->price) * $incomeTransactionItem->amount); ?>

                                        </td>
                                    </tr>
                                    <?php
                                        $number++;
                                        $itemTotal += $incomeTransactionItem->amount;
                                        $totalPrice += $incomeTransactionItem->item->price * $incomeTransactionItem->amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="5" class="text-right">
                                        Total Barang
                                    </th>
                                    <th class="text-right">
                                        <?php echo e($itemTotal); ?>

                                    </th>
                                     <th class="text-right">
                                            <?php echo e(currency($totalPrice)); ?>

                                        </th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
  
        <div class="card-footer text-right">
            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">
                Kembali
            </a>
         <a href="javascript:void(0)" class="btn btn-primary" onclick="printContent()">
        Cetak
    </a>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        function printContent() {
            var content = document.getElementById("print-content").innerHTML;
            var originalContent = document.body.innerHTML;
            document.body.innerHTML = content;
            window.print();
            document.body.innerHTML = originalContent;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\laravel8-inventory-free\resources\views/pages/income-transaction/detail.blade.php ENDPATH**/ ?>