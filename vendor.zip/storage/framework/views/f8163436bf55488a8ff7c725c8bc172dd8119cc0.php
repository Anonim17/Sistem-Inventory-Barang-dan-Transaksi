

<?php $__env->startSection('description', 'Halaman yang berisi daftar data barang dan stok yang dibuat.'); ?>

<?php $__env->startSection('route_name', 'Stok Barang'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="modal fade" id="filterModal" tabindex="-1" aria-labelledby="filterModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form class="modal-content" action="<?php echo e(route('stocks.index')); ?>" method="GET">
                <div class="modal-header" style="background-color: #ff0000;">
                    <h5 class="modal-title" id="filterModalLabel">Sortir / Saring Stok</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <input type="hidden" name="keyword" value="<?php echo e($input['keyword']); ?>">
                        <label for="order_by">Kolom Urut</label>
                        <select class="form-control form-control-sm" id="order_by" name="order_by">
                            <option value="part_number"
                                <?php echo e($input['order_by'] === 'part_number' ? 'selected' : ''); ?>>
                                ID Barang
                            </option>
                            <option value="description"
                                <?php echo e($input['order_by'] === 'description' ? 'selected' : ''); ?>>
                                Deskripsi
                            </option>
                            <option value="price"
                                <?php echo e($input['order_by'] === 'price' ? 'selected' : ''); ?>>
                                Harga
                            </option>
                          
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="order_direction">Arah Urut</label>
                        <select name="order_direction" id="order_direction" class="form-control form-control-sm">
                            <option value="asc"
                                <?php echo e($input['order_direction'] === 'asc' ? 'selected' : ''); ?>>
                                Naik
                            </option>
                            <option value="desc"
                                <?php echo e($input['order_direction'] === 'desc' ? 'selected' : ''); ?>>
                                Turun
                            </option>
                        </select>
                    </div>
                  
                    <div class="row">
                        <div class="col-12">
                            <label for="start_stock">Stok</label>
                        </div>
                    </div>
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="form-group m-0">
                                <input type="number"
                                    class="form-control"
                                    value="<?php echo e($input['start_stock']); ?>"
                                    id="start_stock"
                                    name="start_stock">
                            </div>
                        </div>
                        <div class="col-auto">
                            -
                        </div>
                        <div class="col">
                            <div class="form-group m-0">
                                <input type="number"
                                    class="form-control"
                                    value="<?php echo e($input['end_stock']); ?>"
                                    id="end_stock"
                                    name="end_stock">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
    <div class="card">
        <div class="card-header bg-white">
            <div class="row justify-content-center justify-content-lg-between align-items-center">
                <div class="col-md-7 col-lg-4 mb-2 mb-lg-0">
                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#filterModal" style="background-color: #ff0000;">
                        <i class="fas fa-filter mr-1"></i>
                        Sortir / Saring
                    </button>
                </div>
                <div class="col-lg-auto col-md-5 col-lg-3">
                    <form action="<?php echo e(route('stocks.index')); ?>" method="get">
                        <input type="hidden" name="order_by" value="<?php echo e($input['order_by']); ?>">
                        <input type="hidden" name="order_direction" value="<?php echo e($input['order_direction']); ?>">
                        
                        <input type="hidden" name="start_stock" value="<?php echo e($input['start_stock']); ?>">
                        <input type="hidden" name="end_stock" value="<?php echo e($input['end_stock']); ?>">
                        <div class="input-group input-group-sm">
                            <input type="search"
                                class="form-control"
                                name="keyword"
                                id="q"
                                placeholder="Pencarian"
                                value="<?php echo e(empty($input['keyword']) ? '' : $input['keyword']); ?>">
                            <div class="input-group-append">
                              <button class="btn btn-outline-secondary" type="submit" id="button-addon2">
                                <i class="fas fa-search"></i>
                              </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive mb-3">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center align-middle" style="width: 2px">No</th>
                            <th class="align-middle">ID Barang</th>
                            <th class="align-middle">Deskripsi</th>
                            <th class="align-middle text-right">Harga</th>
                            <th class="align-middle text-right">Stok</th>
                            <th class="align-middle text-right">Cabang</th>
                            <th class="align-middle text-right">Satuan Barang</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($items)): ?>
                            <tr>
                                <td class="text-center" colspan="8">
                                    Data tidak ditemukan.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center align-middle">
                                        <?php echo e($number); ?>

                                    </td>
                                    <td class="align-middle">
                                        <?php echo e($item->part_number); ?>

                                    </td>
                                    <td class="align-middle">
                                        <?php echo e($item->description); ?>

                                    </td>
                                    <td class="align-middle text-right">
                                        <?php echo e('Rp' . currency($item->price)); ?>

                                    </td>
                                     
                                    <td class="align-middle text-right">
                                        <?php echo e($item->stock); ?>

                                    </td>

                                    <td class="align-middle text-right">
                                        <?php echo e($item->keterangan_cabang); ?>

                                    </td>
                                    
                                  <td class="align-middle">
                                        <?php echo e($item->satuan_brg); ?>

                                    </td>
                                </tr>
                                <?php
                                    $number++
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="row justify-content-end">
                <div class="col-auto">
                    <nav>
                        <ul class="pagination pagination-sm">
                            <?php if($input['page'] === 1): ?>
                                <li class="page-item disabled">
                                    <a href="" class="page-link"><<</a>
                                </li>

                                <li class="page-item disabled">
                                    <a href="" class="page-link"><</a>
                                </li>

                                <li class="page-item active">
                                    <a
                                        href="<?php echo e(route('stocks.index', ['page' => 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword'], 'start_stock' => $input['start_stock'], 'end_stock' => $input['end_stock']])); ?>"
                                        class="page-link">
                                        1
                                    </a>
                                </li>

                                <?php for($i = 2; $i <= $pageTotal; $i++): ?>
                                    <?php if($i < 4): ?>
                                        <li class="page-item">
                                            <a class="page-link"
                                                href="<?php echo e(route('stocks.index', ['page' => $i, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword'], 'start_stock' => $input['start_stock'], 'end_stock' => $input['end_stock']])); ?>">
                                                <?php echo e($i); ?>

                                            </a>
                                        </li>
                                    <?php endif; ?>
                                <?php endfor; ?>

                                <li class="page-item">
                                    <a class="page-link"
                                        href="<?php echo e(route('stocks.index', ['page' => $input['page'] + 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword'], 'start_stock' => $input['start_stock'], 'end_stock' => $input['end_stock']])); ?>">
                                        >
                                    </a>
                                </li>

                                <li class="page-item">
                                    <a class="page-link"
                                        href="<?php echo e(route('stocks.index', ['page' => $pageTotal, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword'], 'start_stock' => $input['start_stock'], 'end_stock' => $input['end_stock']])); ?>">
                                        >>
                                    </a>
                                </li>
                            <?php else: ?>
                                <li class="page-item">
                                    <a class="page-link"
                                        href="<?php echo e(route('stocks.index', ['page' => 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword'], 'start_stock' => $input['start_stock'], 'end_stock' => $input['end_stock']])); ?>">
                                        <<
                                    </a>
                                </li>

                                <li class="page-item">
                                    <a class="page-link"
                                        href="<?php echo e(route('stocks.index', ['page' => $input['page'] - 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword'], 'start_stock' => $input['start_stock'], 'end_stock' => $input['end_stock']])); ?>">
                                        <
                                    </a>
                                </li>

                                <?php
                                    $pageStartNumber = $input['page'] !== $pageTotal ? $input['page'] - 1 : $input['page'] - 2;
                                    $loopingNumberStop = $input['page'] !== $pageTotal ? $input['page'] + 1 : $input['page'];
                                    $pageStartNumber = $pageStartNumber < 1 ? 1 : $pageStartNumber;
                                ?>

                                <?php for($i = $pageStartNumber; $i <= $loopingNumberStop; $i++): ?>
                                    <li class="page-item <?php echo e($input['page'] === $i ? 'active' : ''); ?>">
                                        <a class="page-link"
                                            href="<?php echo e(route('stocks.index', ['page' => $i, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword'], 'start_stock' => $input['start_stock'], 'end_stock' => $input['end_stock']])); ?>">
                                            <?php echo e($i); ?>

                                        </a>
                                    </li>
                                <?php endfor; ?>

                                <li class="page-item <?php echo e($input['page'] === $pageTotal ? 'disabled' : ''); ?>">
                                    <a class="page-link"
                                        href="<?php echo e(route('stocks.index', ['page' => $input['page'] + 1, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword'], 'start_stock' => $input['start_stock'], 'end_stock' => $input['end_stock']])); ?>">
                                        >
                                    </a>
                                </li>

                                <li class="page-item <?php echo e($input['page'] === $pageTotal ? 'disabled' : ''); ?>">
                                    <a class="page-link"
                                        href="<?php echo e(route('stocks.index', ['page' => $pageTotal, 'order_by' => $input['order_by'], 'order_direction' => $input['order_direction'], 'keyword' => $input['keyword'], 'start_stock' => $input['start_stock'], 'end_stock' => $input['end_stock']])); ?>">
                                        >>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel8-inventory-free\resources\views/pages/stock/index.blade.php ENDPATH**/ ?>