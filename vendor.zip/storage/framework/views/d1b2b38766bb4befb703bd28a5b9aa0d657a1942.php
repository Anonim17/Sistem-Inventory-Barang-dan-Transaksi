<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\laravel8-inventory-free\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>