

<?php $__env->startSection('title', "$application->name - Merek - $item->part_number"); ?>

<?php $__env->startSection('description', 'Halaman yang berisi informasi detail barang.'); ?>

<?php $__env->startSection('route_name', 'Detail Barang'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h5 class="m-0 text-dark">
                <?php echo e($item->part_number); ?>

            </h5>
        </div>
        <div class="card-body">
       
            <div class="row mb-2">
                <div class="col-md-4 col-lg-3">
                    <b>Deskripsi <span class="d-md-none">:</span></b>
                </div>
                <div class="col-md-8 col-lg-9">
                    <b class="d-none d-md-inline">:</b> <?php echo e($item->description); ?>

                </div>
            </div>
            <div class="row mb-2">
                <div class="col-md-4 col-lg-3">
                    <b>Harga <span class="d-md-none">:</span></b>
                </div>
                <div class="col-md-8 col-lg-9">
                    <b class="d-none d-md-inline">:</b>
                    <?php echo e(currency($item->price)); ?>

                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-lg-3">
                    <b>Gambar <span class="d-md-none">:</span></b>
                </div>
                <div class="col-md-8 col-lg-9">
    <b class="d-none d-md-inline">:</b>
    <?php if(empty($item->image)): ?>
        -
    <?php else: ?>
        <a href="<?php echo e(url("items/$item->id/image")); ?>">
            <img src="<?php echo e(asset($item->image)); ?>" alt="Gambar Barang" width="200" class="img-thumbnail">
        </a>
    <?php endif; ?>
</div>
            </div>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">
                Kembali
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Document\BIMA EC\Program\laravel8-inventory-free\resources\views/pages/item/detail.blade.php ENDPATH**/ ?>