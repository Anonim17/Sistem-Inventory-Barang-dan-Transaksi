

<?php $__env->startSection('description', 'Halaman formulir untuk mengubah profil pengguna.'); ?>

<?php $__env->startSection('route_name', 'Ubah Profil'); ?>

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="m-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible fade show">
        Berhasil mengubah profil.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        Isi formulir
    </div>
    <div class="card-body">
        <form action="<?php echo e(url('profile')); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="name">
                        Nama
                    </label>
                    <input type="text"
                        class="form-control"
                        name="name"
                        id="name"
                        value="<?php echo e(empty(old('name')) ? auth()->user()->name : old('name')); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="username">
                        Username
                    </label>
                    <input type="text"
                        class="form-control"
                        name="username"
                        id="username"
                        value="<?php echo e(empty(old('username')) ? auth()->user()->username : old('username')); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="email">
                        Email
                    </label>
                    <input type="email"
                        class="form-control"
                        name="email"
                        id="email"
                        value="<?php echo e(empty(old('email')) ? auth()->user()->email : old('email')); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="password">
                        Kata Sandi Saat Ini
                    </label>
                    <input type="password"
                        class="form-control"
                        name="password"
                        id="password"
                        placeholder="Isi kata sandi...">
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-block btn-primary">
                        Simpan
                    </button>
                </div>
            </div>
        </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel8-inventory-free\resources\views/pages/profile/edit.blade.php ENDPATH**/ ?>