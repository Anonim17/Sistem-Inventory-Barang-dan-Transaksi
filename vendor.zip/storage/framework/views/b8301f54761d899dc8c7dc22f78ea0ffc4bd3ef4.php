

<?php $__env->startSection('title', "$application->name - Login"); ?>

<?php $__env->startSection('description', 'Halaman formulir pengisian akun untuk masuk ke aplikasi.'); ?>

<?php $__env->startSection('content'); ?>
<div class="body">
    <div class="p-5">
        <div class="text-center">
            <h1 class="h1 text-gray-900 mx-12"><b><?php echo e($application->name); ?></b></h1>
            <h6 class="h4 text-gray-900 mb-12">Auto Sunrise Mandiri</h6>
        </div>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="m-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
        <form class="user" method="POST">
            <?php echo method_field('POST'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" class="form-control" id="exampleInputEmail" placeholder="Username" name="username">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" id="exampleInputPassword" placeholder="Kata sandi" name="password">
            </div>
            <div class="form-group">
                <div class="custom-control custom-checkbox small">
                    <input type="checkbox" class="custom-control-input" id="customCheck" name="remember_me" value="1">
                    <label class="custom-control-label" for="customCheck">
                        Tetap Masuk
                    </label>
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-user btn-block" style="background-color: #000000;">
                Login
            </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Document\BIMA EC\Program\laravel8-inventory-free\resources\views/pages/auth/login.blade.php ENDPATH**/ ?>