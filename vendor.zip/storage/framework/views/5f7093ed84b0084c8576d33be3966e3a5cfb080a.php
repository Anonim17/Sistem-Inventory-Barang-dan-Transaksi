

<?php $__env->startSection('title', "$application->name - Lupa Kata Sandi"); ?>

<?php $__env->startSection('description', 'Halaman formulir pengisian email untuk atur ulang kata sandi.'); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-5">
        <div class="text-center">
            <h1 class="h4 text-gray-900 mb-2">Lupa Kata Sandi</h1>
            <p class="mb-4">
                Masukkan alamat email Anda di bawah ini
                dan kami akan mengirimkan tautan untuk mengatur ulang kata sandi Anda.
            </p>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php if($errors->count() < 2): ?>
                    <ul class="m-0 list-unstyled">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <ul class="m-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <form class="user" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="email"
                    class="form-control form-control-user"
                    id="exampleInputEmail"
                    aria-describedby="emailHelp"
                    placeholder="Ketikkan alamat email..."
                    name="email">
            </div>
            <button type="submit" class="btn btn-primary btn-user btn-block">
                Ubah Kata Sandi
            </button>
        </form>
        <hr>
        <div class="text-center">
            <a class="small" href="<?php echo e(url('')); ?>">Masuk</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel8-inventory-free\resources\views/pages/auth/forgot-password.blade.php ENDPATH**/ ?>