

<?php $__env->startSection('title', "$application->name - Ubah Pengaturan Aplikasi"); ?>

<?php $__env->startSection('description', 'Halaman formulir untuk mengubah pengaturan aplikasi.'); ?>

<?php $__env->startSection('route_name', 'Ubah Pengaturan Aplikasi'); ?>

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="m-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo e(session('status')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        Isi formulir
    </div>
    <div class="card-body">
        <form action="<?php echo e(url('application')); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="name">
                        Nama
                    </label>
                    <input type="text"
                        class="form-control"
                        name="name"
                        id="name"
                        value="<?php echo e(empty(old('name')) ? $application->name : old('name')); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="copyright">
                        Copyright
                    </label>
                    <input type="text"
                        class="form-control"
                        name="copyright"
                        id="copyright"
                        value="<?php echo e(empty(old('copyright')) ? $application->copyright : old('copyright')); ?>">
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-block btn-primary">
                        Simpan
                    </button>
                </div>
            </div>
        </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\laravel8-inventory-free\resources\views/pages/application/edit.blade.php ENDPATH**/ ?>