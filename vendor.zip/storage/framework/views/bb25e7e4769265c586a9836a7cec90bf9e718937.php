<footer class="sticky-footer" style="background-color: rgba(255, 0, 0,0.65 );">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span style="color:#ffffff;">Copyright &copy; <?php echo e($applicationCopyright); ?></span>
        </div>
    </div>
</footer><?php /**PATH D:\Data\Document\BIMA EC\Program\laravel8-inventory-free\resources\views/components/footer.blade.php ENDPATH**/ ?>